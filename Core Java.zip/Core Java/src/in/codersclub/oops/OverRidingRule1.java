package in.codersclub.oops;

public class OverRidingRule1 
{
    public Object m1()
    {
        return null;
    }
}
class Riding1 extends OverRidingRule1 
{
    public String m1()
    {
        return null;
    }
}