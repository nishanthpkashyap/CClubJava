package in.codersclub.oops;

interface P1
{}
interface P2
{}
interface P3 extends P1,P2
{}