package in.codersclub.sampleprograms;

public class Summation2 
{
    public static int sum(int i)
    {
        int sum;
        sum=(i*(i+1))/2;
        return sum;
    }
}
