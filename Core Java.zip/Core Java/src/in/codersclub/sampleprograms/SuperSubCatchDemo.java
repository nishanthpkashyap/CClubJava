package in.codersclub.sampleprograms;

public class SuperSubCatchDemo
{
    public static void main(String[] args) 
    {
        SuperSubCatch.catchIt();
    }
}
