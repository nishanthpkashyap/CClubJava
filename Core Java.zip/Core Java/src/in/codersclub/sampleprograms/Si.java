package in.codersclub.sampleprograms;

public class Si 
{
    
    public static double calc(double p,double t,double r)
    {
        double si;
        si=(p*t*r)/100;
        return si;
    }
}