package in.codersclub.sampleprograms;

public class Square2 
{
    
    public static int findSqr(int i)
    {
        int sum;
        sum = (i*(i+1)*((2*i)+1))/6;
        return sum;
    }
}
