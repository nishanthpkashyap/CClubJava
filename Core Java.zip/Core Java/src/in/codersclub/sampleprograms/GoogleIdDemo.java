package in.codersclub.sampleprograms;

public class GoogleIdDemo 
{
    public static void main(String[] args) 
    {
        System.out.println("Google meet id is : \n"+GoogleId.generate());
    }
}
