package in.codersclub.sampleprograms;

public class Greater
{
    public static int find(int a,int b)
    {
        if(a>b)
        return a;
        else
        return b;
    }
}

