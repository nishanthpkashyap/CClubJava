package in.codersclub.sampleprograms;

public class CurrentTimeDemo 
{
    public static void main(String[] args) 
    {
        System.out.println("MY CURRENT TIME IS:");
        System.out.println(CurrentTime.myTime());
    }

}
