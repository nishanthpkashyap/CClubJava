package in.codersclub.sampleprograms;

public class QuoRem 
{
    public static int calc(int dividend,int divisor)
    {
        int remainder;
        remainder=dividend%divisor;
        return remainder;
    }
    public static int calc2(int dividend,int divisor)
    {
        int quotient;
        quotient=dividend/divisor;
        return quotient;
    }
}
