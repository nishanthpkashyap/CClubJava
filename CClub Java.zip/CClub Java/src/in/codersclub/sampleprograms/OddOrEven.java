package in.codersclub.sampleprograms;

public class OddOrEven 
{
    public static String calc(int a) 
    {
        String result;
        if((a%2)==0)
            result="EVEN";
        else
            result="ODD";   
        return result;    
    }
}
