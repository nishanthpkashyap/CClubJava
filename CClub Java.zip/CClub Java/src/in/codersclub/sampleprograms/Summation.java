package in.codersclub.sampleprograms;

public class Summation 
{
    public static int sum(int n)
    {
        int s=0;
        for(int i=1;i<=n;i++)
            s=s+i;
        return s;
    }
}
