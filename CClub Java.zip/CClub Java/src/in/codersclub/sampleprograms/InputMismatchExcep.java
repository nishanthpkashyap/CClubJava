package in.codersclub.sampleprograms;

public class InputMismatchExcep
{
    public static int assigner(int num)
    {
        int n = num;
        return n;
    }
}
