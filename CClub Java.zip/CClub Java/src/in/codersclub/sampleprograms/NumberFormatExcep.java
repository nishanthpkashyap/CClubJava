package in.codersclub.sampleprograms;

public class NumberFormatExcep 
{
    public static int converter(String str)
    {
        int a;
        a=Integer.parseInt(str);
        return a;
    }
}
