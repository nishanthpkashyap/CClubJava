package in.codersclub.sampleprograms;

public class RandomGenDemo
{
    public static void main(String[] args) 
    {
        int min=1,max=100;
        System.out.println("The random number generated:\n"+RandomGen.generate(min,max)); 
    }
}