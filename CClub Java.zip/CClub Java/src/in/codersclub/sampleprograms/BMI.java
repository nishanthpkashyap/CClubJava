package in.codersclub.sampleprograms;

public class BMI 
{
    public static float calc(float weight,float height)
    {
        float bmi = (weight/(height*height));
        return bmi;
    }
}
