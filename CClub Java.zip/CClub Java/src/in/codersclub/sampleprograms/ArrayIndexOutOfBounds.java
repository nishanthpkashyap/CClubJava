package in.codersclub.sampleprograms;

public class ArrayIndexOutOfBounds 
{
    public static void enterarray()
    {
        int a[]={10,20,30,40,50,60};
        a[10] = 90;

    }
}
