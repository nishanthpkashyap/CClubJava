package in.codersclub.sampleprograms;

public class ArrayIndexOutOfBoundsDemo 
{
    public static void main(String[] args) 
    {
        ArrayIndexOutOfBounds.enterarray();
    }
}
