package in.codersclub.sampleprograms;

public class Init2dArray 
{
    public static int[][] init()
    {
        int a[][]={{10,20},{30,40}};
        return a;
    }
}
