package in.codersclub.sampleprograms;

public class CurrentDateDemo 
{
    public static void main(String[] args) 
    {
        System.out.println("My Current Time is:");
        System.out.println(CurrentDate.curDate());
    }
}
