package in.codersclub.sampleprograms;

public class StringOutOfBoundsDemo 
{
    public static void main(String[] args) 
    {
        StringOutOfBounds.show();
    }
}
