package in.codersclub.sampleprograms;

public class InitArray 
{
    public static int[] init()
    {
        int a[]={10,20,30,40,50,60};
        return a;
    } 
}
