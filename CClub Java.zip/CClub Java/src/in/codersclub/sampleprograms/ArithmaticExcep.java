package in.codersclub.sampleprograms;

public class ArithmaticExcep 
{
    public static int divide(int a,int b)
    {
        int q = a/b;
        return q;
    }
}
